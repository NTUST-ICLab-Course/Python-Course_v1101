'''
這個 CLI 的程式是在 setup 之後，在 console 可以要說明性的 help，長得如下：
===
usage: unitconvert [-h] TABLE {list,convert} ...

Tool for converting units

positional arguments:
  TABLE           Unit table to use in conversion
  {list,convert}  operation to be performed

optional arguments:
  -h, --help      show this help message and exit
  
'''

import argparse
import inspect
from .Converter import get_table, convert_units


def run_cli():
    parser = argparse.ArgumentParser(description='Tool for converting units')

    parser.add_argument(
        'table',
        metavar='TABLE',
        action='store',
        type=str,
        help='Unit table to use in conversion'
    )

    """
    這是 unitconvert 以及上述 table 之後，第二層要解碼的部份，
    這又分為兩個：
    1. list
    2. convert
    我們安排一個 which 變數來記錄是哪一個。
    """
    subparsers = parser.add_subparsers(help='operation to be performed')

    '''
    以下考慮 -m, --method 的選項，要作什麼事
    
    Unit table energy can convert between the units:
    kcal (x * 0.00023884589663)
    cal (x * 0.23900573614)
    btu (x * 0.00094781707775)
    ev (x * 6241506480000000000.0)
    wh (x * 0.00027777777778)
    j (base unit)
    hph (x * 3.7250614123e-7)
    '''
    
    list_table_parser = subparsers.add_parser('list')
    list_table_parser.set_defaults(which='list')

    list_table_parser.add_argument(
        '-m', '--method',
        action='store_true',
        help='Also output the conversion method from the base unit'
    )
    
    '''
    以下考慮 convert 時，要作什麼事
    
    usage: unitconvert TABLE convert [-h] VALUE FROM TO [TO ...]

    positional arguments:
      VALUE       The value to convert
      FROM        Unit to convert from
      TO          Unit(s) to convert to

    optional arguments:
      -h, --help  show this help message and exit
    '''

    conversion_parser = subparsers.add_parser('convert')
    conversion_parser.set_defaults(which='convert')

    conversion_parser.add_argument(
        'value',
        metavar='VALUE',
        type=float,
        action='store',
        help='The value to convert'
    )

    conversion_parser.add_argument(
        'from_unit',
        metavar='FROM',
        action='store',
        type=str,
        help='Unit to convert from'
    )

    conversion_parser.add_argument(
        'to_units',
        metavar='TO',
        action='store',
        nargs='+', # 個數可以有很多個，但至少會有一個
        type=str,
        help='Unit(s) to convert to'
    )

    """
    以下這個指令 parser.parse_args() 是最重要的，
    將 CLI 輸入的參數按指定的名稱取出，
    然後，就可以作判斷，要作怎樣的反應。
    """
    props = parser.parse_args()

    if props.which == 'list':
        _run_unit_list(props)
    elif props.which == 'convert':
        _run_conversion(props)


def _run_unit_list(props):
    """
    Runs the command line interface for unit listing mode.

    @param props Properties parsed by argparse
    """

    table = get_table(props.table)
    print('Unit table %s can convert between the units:' % props.table)
    for unit in table.get_units():
        if props.method:
            if unit == table.base_unit:
                formula = 'base unit'
            else:
                conversion = inspect.getsource(table.from_base_unit[unit])
                """
                self.from_base_unit['radian'] = lambda x: x * 0.0174532925
                """
                formula = conversion[conversion.index(':') + 1:conversion.index('\n')].strip() # 這是要將一開頭的 [lambda x:] 給去掉
            print('%s (%s)' % (unit, formula))
        else:
            print(unit)


def _run_conversion(props):
    """
    Runs the command line interface for unit conversion mode.

    @param props Properties parsed by argparse
    """

    results = convert_units(table_name=props.table,
                            value=props.value,
                            value_unit=props.from_unit,
                            targets=props.to_units)

    for result in results:
        print('%f %s = %f %s' % (props.value, props.from_unit,
                                 result['converted_value'],
                                 result['dest_unit']))
